<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProdutosController;
use Illuminate\Support\Facades\URL;


URL::forceScheme('http');

// pagina inicial do Produtos
Route::get('/', ProdutosController::class .'@index')->name('produtos.index');
// vai para o form que faz o cadastro do novo Produtos
Route::get('/produtos/criar', ProdutosController::class . '@criar')->name('produtos.criar');
// salva o Produtos na base de dados
Route::post('/produtos', ProdutosController::class .'@salvar')->name('produtos.salvar');
// returns a page that shows a full post
Route::get('/produtos/{produtos}', ProdutosController::class .'@deletar')->name('produtos.deletar');
// vai para o form que faz a atualizacao do Produtos
Route::get('/produtos/{produtos}/editar', ProdutosController::class .'@editar')->name('produtos.editar');
//altera o Produtos na base de dados
Route::put('/produtos/{produtos}', ProdutosController::class .'@alterar')->name('produtos.alterar');
// exclui o Produtos cadastrado no bd
Route::delete('/produtos/{produtos}', ProdutosController::class .'@excluir')->name('produtos.excluir');





