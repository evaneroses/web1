<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>

<valor>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand h1" href=<?php echo e(route('produtos.index')); ?>>Cadastro de Produtos</a>
            <div class="justify-end ">
                <div class="col ">
                    <a class="btn btn-sm btn-success" href=<?php echo e(route('produtos.index')); ?>>Inicio</a>
                </div>
            </div>
    </nav>

    <div class="container h-100 mt-5">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-10 col-md-8 col-lg-6">
            <img src="https://www.escoladeestilo.com.br/wp-content/uploads/2020/08/capa-brech%C3%B3.jpg" alt="Brecho" width="300" height="200">
            <div class="col-10 col-md-8 col-lg-6">
                <h3>Cadastrar Produto</h3>
                <form action="<?php echo e(route('produtos.salvar')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nome">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="form-group">
                        <label for="valor">Preço</label>
                         <input type="text" class="form-control" id="valor" name="valor" required></textarea>
                    </div>
                    <br>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </form>
            </div>
        </div>
    </div>
</div>
</valor>

</html>
<?php /**PATH C:\Users\Windows\meu-site\resources\views/produtos/criar.blade.php ENDPATH**/ ?>