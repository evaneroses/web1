<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <title>LOJINHA BRECHO </title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand h1" href=<?php echo e(route('posts.index')); ?>>BRECHÓ DA ROSE</a>
            <div class="justify-end ">
                <div class="col ">
                    <a class="btn btn-sm btn-success" href=<?php echo e(route('posts.create')); ?>>Cadastrar Produto</a>
                </div>
            </div>
    </nav>
    <div class="container mt-5">
        <div class="row">
            <table class="mdl-data-table dataTable listar">
          <thead>
            <th>Nome</th>
            <th>Preço</th>
            <th>Editar</th>
            <th>Excluir</th>
          </thead>
          <tbody>
             <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr  class="btnExcluir">
              <td><?php echo e($post->title); ?></td>
              <td><?php echo e($post->body); ?></td>
              <td><a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary btn-sm">Editar</a></td>
                 <td><a href="<?php echo e(route('posts.destroy', $post->id)); ?>"class="btn btn-danger btn-sm">Excluir</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        </div>
</body>

</html>
<?php /**PATH C:\Users\Windows\meu-site\resources\views/posts/index.blade.php ENDPATH**/ ?>