<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProdutosController;
use Illuminate\Http\Request;
use App\Models\Produtos;

class ProdutosController extends Controller
{
   
    public function index()
    {
        $produtos = Produtos::all();

        return view('produtos.index', compact('produtos'));
    }

    public function salvar(Request $request)
    {
        $request->validate([
            'nome' => 'required|max:255',
            'valor' => 'required',
        ]);
        Produtos::create($request->all());
        return redirect()->route('produtos.index')
            ->with('success', 'Produto Cadastrado com Sucesso');
    }

    public function alterar(Request $request, $id)
    {
        $request->validate([
            'nome' => 'required|max:255',
            'valor' => 'required',
        ]);

        $produtos = Produtos::find($id);
        $produtos->update($request->all());

        return redirect()->route('produtos.index')
            ->with('success', 'Produto alterado com Sucesso');
    }
    public function excluir($id)
    {

        $produtos = Produtos::find($id);
        $produtos->delete();

        return redirect()->route('produtos.index')
            ->with('success', 'Produto Excluido com Sucesso');
    }

    public function criar()
    {
        return view('produtos.criar');
    }

    public function deletar($id)
    {
        $produtos = Produtos::find($id);

        return view('produtos.deletar', compact('produtos'));
    }

    public function editar($id)
    {
        $produtos = Produtos::find($id);

        return view('produtos.editar', compact('produtos'));
    }
}
